from pystyle import Colors, Colorate
import os
import zipfile
import tarfile

try:
    import py7zr
except Exception:
    py7zr = None

try:
    import patoolib
except Exception:
    patoolib = None

gradient = Colors.green_to_cyan
OUT_DIR = "out"

function = [
    "1) Pack ZIP", "2) Pack 7Z", "3) Pack TAR", "4) Pack TAR.GZ", "5) Pack TAR.BZ2",
    "6) Pack TAR.XZ", "7) Pack ARJ", "8) Unpack ZIP", "9) Unpack 7Z", "10) Unpack TAR",
    "11) Unpack TAR.GZ", "12) Unpack TAR.BZ2", "13) Unpack TAR.XZ", "14) Unpack ARJ", "15) Выход"
]


# Получает ширину терминала
def safe_terminal_width(default=120):
    try:
        return os.get_terminal_size().columns
    except Exception:
        return default

def baner():
    art = r"""
░▒▓████████▓▒░▒▓██████▓▒░░▒▓███████▓▒░░▒▓████████▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓████████▓▒░▒▓███████▓▒░
░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░
░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░       ░▒▓█▓▒▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░
░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓███████▓▒░░▒▓██████▓▒░  ░▒▓█▓▒▒▓█▓▒░░▒▓██████▓▒░ ░▒▓███████▓▒░
░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░        ░▒▓█▓▓█▓▒░ ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░
░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░        ░▒▓█▓▓█▓▒░ ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░
░▒▓█▓▒░      ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓████████▓▒░  ░▒▓██▓▒░  ░▒▓████████▓▒░▒▓█▓▒░░▒▓█▓▒░
"""

    width = safe_terminal_width()
    print(Colorate.Horizontal(gradient, art.center(width)))
    print(Colorate.Horizontal(gradient, "[ by @DreamDolphin ]".center(width)))
    print("\n")


# Создаёт рамку для меню
def framed_column(items, width=26):
    col = ["┌" + "─" * width + "┐"]

    for item in items:
        col.append(f"│ {item.ljust(width - 2)}│")

    col.append("└" + "─" * width + "┘")
    return col


# Показывает главное меню
def menu():
    term_width = safe_terminal_width()

    left = framed_column(function[:5])
    right = framed_column(function[5:10])
    center = framed_column(function[10:])

    for l, r in zip(left, right):
        print(
            Colorate.Horizontal(
                gradient,
                (" " * 4 + l + "   " + r).center(term_width)
            )
        )

    print()

    for line in center:
        print(
            Colorate.Horizontal(
                gradient,
                line.center(term_width)
            )
        )

    print("\n")


# Создаёт папку для результатов.
def ensure_out_dir():
    if not os.path.exists(OUT_DIR):
        os.makedirs(OUT_DIR, exist_ok=True)


# Формирует путь выходного файла.
def base_out_file(filename, ext):
    base = os.path.basename(filename)
    return os.path.join(OUT_DIR, f"{base}.{ext}")


# Создаёт ZIP-архив.
def compress_zip(src):
    ensure_out_dir()

    out_file = base_out_file(src, "zip")

    with zipfile.ZipFile(
        out_file,
        "w",
        zipfile.ZIP_DEFLATED
    ) as zf:

        if os.path.isdir(src):
            for root, _, files in os.walk(src):
                for f in files:
                    full = os.path.join(root, f)
                    arc = os.path.relpath(
                        full,
                        start=os.path.dirname(src)
                    )
                    zf.write(full, arcname=arc)
        else:
            zf.write(
                src,
                arcname=os.path.basename(src)
            )

    return out_file


# Создаёт TAR-архив с выбранным сжатием.
def compress_tar(src, mode):
    ensure_out_dir()

    ext = mode.split(":")[1] if ":" in mode else mode

    out_file = base_out_file(
        src,
        f"tar.{ext}" if ext else "tar"
    )

    with tarfile.open(out_file, mode) as tf:
        tf.add(
            src,
            arcname=os.path.basename(src)
        )

    return out_file

# Создаёт 7Z-архив.
def compress_7z(src):
    ensure_out_dir()

    out_file = base_out_file(src, "7z")

    os.system(f'7zz a "{out_file}" "{src}"')

    return out_file

# Создаёт ARJ-архив.
def compress_arj(src):
    if patoolib is None:
        print(
            Colorate.Horizontal(
                gradient,
                "patoolib не установлен! pip install patool"
            )
        )
        return None

    ensure_out_dir()

    out_file = base_out_file(src, "arj")

    patoolib.create_archive(
        out_file,
        (src,)
    )

    return out_file


# Распаковывает ZIP-архив.
def extract_zip(path):
    ensure_out_dir()

    out_dir = os.path.join(
        OUT_DIR,
        os.path.basename(path) + "_unpacked"
    )

    with zipfile.ZipFile(
        path,
        "r"
    ) as zf:
        zf.extractall(out_dir)

    return out_dir


# Распаковывает TAR-архив.
def extract_tar(path):
    ensure_out_dir()

    out_dir = os.path.join(
        OUT_DIR,
        os.path.basename(path) + "_unpacked"
    )

    with tarfile.open(
        path,
        "r:*"
    ) as tf:
        tf.extractall(out_dir)

    return out_dir

# Распаковывает 7Z-архив.
def extract_7z(path):
    ensure_out_dir()

    out_dir = os.path.join(
        OUT_DIR,
        os.path.basename(path) + "_unpacked"
    )

    os.system(f'7zz x "{path}" -o"{out_dir}" -y')

    return out_dir

# Распаковывает ARJ-архив.
def extract_arj(path):
    if patoolib is None:
        print(
            Colorate.Horizontal(
                gradient,
                "patoolib не установлен!"
            )
        )
        return None

    ensure_out_dir()

    out_dir = os.path.join(
        OUT_DIR,
        os.path.basename(path) + "_unpacked"
    )

    patoolib.extract_archive(
        path,
        outdir=out_dir
    )

    return out_dir


# Обрабатывает выбранную пользователем функцию.
def handle_function(func, file_path):
    try:
        if func == "1":
            out_file = compress_zip(file_path)

        elif func == "2":
            out_file = compress_7z(file_path)

        elif func == "3":
            out_file = compress_tar(file_path, "w")

        elif func == "4":
            out_file = compress_tar(file_path, "w:gz")

        elif func == "5":
            out_file = compress_tar(file_path, "w:bz2")

        elif func == "6":
            out_file = compress_tar(file_path, "w:xz")

        elif func == "7":
            out_file = compress_arj(file_path)

        elif func == "8":
            out_file = extract_zip(file_path)

        elif func == "9":
            out_file = extract_7z(file_path)

        elif func == "10":
            out_file = extract_tar(file_path)

        elif func == "11":
            out_file = extract_tar(file_path)

        elif func == "12":
            out_file = extract_tar(file_path)

        elif func == "13":
            out_file = extract_tar(file_path)

        elif func == "14":
            out_file = extract_arj(file_path)

        else:
            return

        if out_file:
            print(
                Colorate.Horizontal(
                    gradient,
                    f"[ + ] Успешно! Результат: {out_file}"
                )
            )
        else:
            print(
                Colorate.Horizontal(
                    gradient,
                    "[ - ] Произошла ошибка."
                )
            )

    except Exception as e:
        print(
            Colorate.Horizontal(
                gradient,
                f"[ - ] Ошибка: {e}"
            )
        )


# Запускает основной цикл программы.
def main():
    script_name = os.path.basename(__file__)

    while True:
        baner()
        menu()

        choice = input(
            Colorate.Horizontal(
                gradient,
                "Введите номер функции: "
            )
        ).strip()

        if choice == "15":
            print(
                Colorate.Horizontal(
                    gradient,
                    "Выход..."
                )
            )
            break

        if choice not in [str(i) for i in range(1, 15)]:
            print(
                Colorate.Horizontal(
                    gradient,
                    "Неверный выбор!"
                )
            )

            input(
                Colorate.Horizontal(
                    gradient,
                    "[Enter] для возврата в меню..."
                )
            )

            continue

        files = [
            f
            for f in os.listdir(".")
            if os.path.isfile(f) and f != script_name
        ]

        if not files:
            print(
                Colorate.Horizontal(
                    gradient,
                    "В текущей папке нет файлов!"
                )
            )

            input(
                Colorate.Horizontal(
                    gradient,
                    "[Enter] для возврата в меню..."
                )
            )

            continue

        print(
            Colorate.Horizontal(
                gradient,
                "\nФайлы:"
            )
        )

        for i, f in enumerate(files, 1):
            print(
                Colorate.Horizontal(
                    gradient,
                    f"{i}) {f}"
                )
            )

        file_choice = input(
            Colorate.Horizontal(
                gradient,
                "Введите номер файла: "
            )
        ).strip()

        if (
            not file_choice.isdigit()
            or not (1 <= int(file_choice) <= len(files))
        ):
            print(
                Colorate.Horizontal(
                    gradient,
                    "Неверный выбор!"
                )
            )

            input(
                Colorate.Horizontal(
                    gradient,
                    "[Enter] для возврата в меню..."
                )
            )

            continue

        file_path = files[int(file_choice) - 1]

        handle_function(
            choice,
            file_path
        )

        input(
            Colorate.Horizontal(
                gradient,
                "[Enter] для возврата в меню..."
            )
        )


if __name__ == "__main__":
    main()