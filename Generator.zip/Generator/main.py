import os
import random
from pystyle import Colors, Colorate, Write

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
gradient = Colors.green_to_white

#банер
baner = r"""
      ___           ___           ___           ___           ___           ___                         ___           ___              
     /\__\         /\__\         /\  \         /\__\         /\  \         /\  \                       /\  \         /\  \             
    /:/ _/_       /:/ _/_        \:\  \       /:/ _/_       /::\  \       /::\  \         ___         /::\  \       /::\  \            
   /:/ /\  \     /:/ /\__\        \:\  \     /:/ /\__\     /:/\:\__\     /:/\:\  \       /\__\       /:/\:\  \     /:/\:\__\           
  /:/ /::\  \   /:/ /:/ _/_   _____\:\  \   /:/ /:/ _/_   /:/ /:/  /    /:/ /::\  \     /:/  /      /:/  \:\  \   /:/ /:/  /           
 /:/__\/\:\__\ /:/_/:/ /\__\ /::::::::\__\ /:/_/:/ /\__\ /:/_/:/__/___ /:/_/:/\:\__\   /:/__/      /:/__/ \:\__\ /:/_/:/__/___         
 \:\  \ /:/  / \:\/:/ /:/  / \:\~~\~~\/__/ \:\/:/ /:/  / \:\/:::::/  / \:\/:/  \/__/  /::\  \      \:\  \ /:/  / \:\/:::::/  /         
  \:\  /:/  /   \::/_/:/  /   \:\  \        \::/_/:/  /   \::/~~/~~~~   \::/__/      /:/\:\  \      \:\  /:/  /   \::/~~/~~~~          
   \:\/:/  /     \:\/:/  /     \:\  \        \:\/:/  /     \:\~~\        \:\  \      \/__\:\  \      \:\/:/  /     \:\~~\              
    \::/  /       \::/  /       \:\__\        \::/  /       \:\__\        \:\__\          \:\__\      \::/  /       \:\__\             
     \/__/         \/__/         \/__/         \/__/         \/__/         \/__/           \/__/       \/__/         \/__/  
[ by: @DreamDolphin ]          
"""
#запрос к файлам 
def get_files(gender):
    return {
        "Имя": f"Имена_{gender}.txt",
        "Фамилия": f"Фамилии_{gender}.txt",
        "Отчество": f"Отчества_{gender}.txt",
        "Работа": f"Работы_{gender}.txt",
        "Адрес": f"Адреса_{gender}.txt",
        "Город": f"Города_{gender}.txt",
        "Телефон": f"Телефон_{gender}.txt",
        "Машины": f"Маш_{gender}.txt",
        "Год рождения": f"Года_{gender}.txt",
        "Сети": f"Сети_{gender}.txt"
    }

#патчи файлов 
def file_path(file_name, gender):
    possible_paths = [
        os.path.join(BASE_DIR, "Generator", gender, file_name),
        os.path.join(BASE_DIR, gender, file_name),
        os.path.join(BASE_DIR, file_name)
    ]
    for p in possible_paths:
        if os.path.exists(p):
            return p
    return None

#чтение файлов 
def load_list(file_name, gender):
    path = file_path(file_name, gender)
    if not path:
        return [f"⚠ Файл {file_name} не найден (пытался в Generator/{gender} и в папке скрипта)"]

    try:
        with open(path, encoding="utf-8") as f:
            content = f.read().strip()

            if "," in content:
                items = [x.strip() for x in content.replace("\n", "").split(",") if x.strip()]
            else:
                items = [line.strip() for line in content.splitlines() if line.strip()]

            return items if items else [f"⚠ Файл {os.path.basename(path)} пустой"]
    except Exception as e:
        return [f"⚠ Ошибка чтения {os.path.basename(path)}: {e}"]

#генератор
def generator(gender):
    files_map = get_files(gender)
    profile = {}
    for key, file_name in files_map.items():
        options = load_list(file_name, gender)
        profile[key] = random.choice(options)
    return profile

#функция меню
def main():
    print(Colorate.Horizontal(gradient, baner))

    while True:
        gender = input(Colorate.Horizontal(gradient, "Выберите пол (жен/муж): ")).strip().lower()
        if gender not in ("жен", "муж"):
            print(Colorate.Horizontal(gradient, "Ошибка: введите 'жен' или 'муж'"))
            continue

        profile = generator(gender)

        output = ""
        for key, value in profile.items():
            output += f"\n{Colorate.Horizontal(gradient, key)}: {Colorate.Horizontal(gradient, str(value))}\n"

        print(output)
        input(Colorate.Horizontal(gradient, "\nНажмите Enter, чтобы сгенерировать снова..."))

if __name__ == "__main__":
    main()