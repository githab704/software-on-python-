import os, re, requests, http.server, socketserver, subprocess
from urllib.parse import urljoin, urlparse, unquote
from bs4 import BeautifulSoup
from pystyle import Colors, Colorate

baner = r"""
 ███▄ ▄███▓▓██   ██▓  ██████ ▄▄▄█████▓▓█████  ██▀███ ▓██   ██▓
▓██▒▀█▀ ██▒ ▒██  ██▒▒██    ▒ ▓  ██▒ ▓▒▓█   ▀ ▓██ ▒ ██▒▒██  ██▒
▓██    ▓██░  ▒██ ██░░ ▓██▄   ▒ ▓██░ ▒░▒███   ▓██ ░▄█ ▒ ▒██ ██░
▒██    ▓██   ░ ▐██▓░  ▒   ██▒░ ▓██▓ ░ ▒▓█  ▄ ▒██▀▀█▄   ░ ▐██▓░
▒██▒   ░██▒  ░ ██▒▓░▒██████▒▒  ▒██▒ ░ ░▒████▒░██▓ ▒██▒ ░ ██▒▓░
░ ▒░   ░  ░   ██▒▒▒ ▒ ▒▓▒ ▒ ░  ▒ ░░   ░░ ▒░ ░░ ▒▓ ░▒▓░  ██▒▒▒
░  ░      ░ ▓██ ░▒░ ░ ░▒  ░ ░    ░     ░ ░  ░  ░▒ ░ ▒░▓██ ░▒░
░      ░    ▒ ▒ ░░  ░  ░  ░    ░         ░     ░ ░   ░ ▒ ▒ ░░
       ░    ░ ░           ░              ░  ░   ░     ░ ░
            ░ ░                                       ░ ░
"""

print(Colorate.Horizontal(Colors.blue_to_white, baner, 1))
print(Colorate.Horizontal(Colors.blue_to_white, "[ by: @DreamDolphin ]", 1))
print(Colorate.Horizontal(Colors.blue_to_white, "[ популярные ссылки: ]\n", 1))

links = [
    "https://max.ru/",
    "https://web.telegram.org/k/",
    "https://chatgpt.com/",
    "https://m.vk.com/feed",
    "https://www.wildberries.ru",
    "https://www.tiktok.com/ru-RU/"
]

row_size = 3
rows = [links[i:i+row_size] for i in range(0, len(links), row_size)]

for row in rows:
    max_len = max(len(link) for link in row) + 2

    top = "  ".join(
        "╔" + "═" * max_len + "╗"
        for link in row
    )

    mid = "  ".join(
        "║ " + link.ljust(max_len - 1) + "║"
        for link in row
    )

    bot = "  ".join(
        "╚" + "═" * max_len + "╝"
        for link in row
    )

    print(Colorate.Horizontal(Colors.blue_to_white, top, 1))
    print(Colorate.Horizontal(Colors.blue_to_white, mid, 1))
    print(Colorate.Horizontal(Colors.blue_to_white, bot, 1))


PORT = 8080
BASE_DIR = "sites"

os.makedirs(BASE_DIR, exist_ok=True)

TIMEOUT = 15

session = requests.Session()
session.headers.update({
    "User-Agent": "Mozilla/5.0 (clonebot)"
})


#создания безопасного имени файла из URL
def filename_url(src_url):
    parsed = urlparse(src_url)

    path = parsed.path or "/"
    path = path.lstrip("/")

    if not path:
        path = parsed.netloc

    return unquote(path)


#создания для нужных директорий
def dir(path):
    d = os.path.dirname(path)

    if d:
        os.makedirs(d, exist_ok=True)


#проверка является ли строка Data URI
def data_uri(s):
    return (
        isinstance(s, str)
        and s.startswith("data:")
    )


#функция для проверки корректности ресурса
def valid(s):
    if not s or not isinstance(s, str):
        return False

    s = s.strip()

    if (
        s.startswith("javascript:")
        or s.startswith("mailto:")
    ):
        return False

    return True


#скачивание бинарного файла
def download_binary(full_url, dest_path):
    try:
        dir(dest_path)

        r = session.get(
            full_url,
            timeout=TIMEOUT,
            stream=True
        )

        r.raise_for_status()

        with open(dest_path, "wb") as wf:
            for chunk in r.iter_content(65536):
                if chunk:
                    wf.write(chunk)

        return True

    except Exception:
        return False


#функция для скачивания текстового ресурса
def download_text(full_url):
    try:
        print(
            Colorate.Horizontal(
                Colors.blue_to_white,
                f"[↓] CSS: {full_url}",
                1
            )
        )

        r = session.get(
            full_url,
            timeout=TIMEOUT
        )

        r.raise_for_status()

        print(
            Colorate.Horizontal(
                Colors.blue_to_white,
                f"[+] CSS получен: {full_url}",
                1
            )
        )

        return r.text

    except Exception as e:

        print(
            Colorate.Horizontal(
                Colors.blue_to_white,
                f"[!] Ошибка CSS: {full_url} — {e}",
                1
            )
        )

        return None


#скачивание ресурса и сохранение его локально
def download_save(full_url, dest_folder):
    try:
        parsed = urlparse(full_url)

        if not parsed.scheme:
            return None

        if parsed.scheme == "data":
            return None

        local_path_rel = filename_url(full_url)

        if local_path_rel.endswith("/"):
            local_path_rel = os.path.join(
                local_path_rel,
                "index"
            )

        dest_path = os.path.join(
            dest_folder,
            local_path_rel
        )

        dir(dest_path)

        print(
            Colorate.Horizontal(
                Colors.blue_to_white,
                f"[↓] {full_url}",
                1
            )
        )

        ok = download_binary(
            full_url,
            dest_path
        )

        if not ok:

            print(
                Colorate.Horizontal(
                    Colors.blue_to_white,
                    f"[!] Ошибка скачивания: {full_url}",
                    1
                )
            )

            return None

        print(
            Colorate.Horizontal(
                Colors.blue_to_white,
                f"[+] Сохранено: {local_path_rel}",
                1
            )
        )

        return os.path.relpath(
            dest_path,
            dest_folder
        ).replace("\\", "/")

    except Exception as e:

        print(
            Colorate.Horizontal(
                Colors.blue_to_white,
                f"[!] Ошибка: {full_url} — {e}",
                1
            )
        )

        return None


#ввод адреса сайта
input_url = input(
    Colorate.Horizontal(
        Colors.blue_to_white,
        "\nВведите адрес сайта: ",
        1
    )
).strip()


#если пользователь ввёл только домен
if (
    not input_url.startswith("http://")
    and not input_url.startswith("https://")
):
    input_url = "https://" + input_url


input_url = input_url.rstrip("/") + "/"


base_url = input_url


site_name = (
    input_url
    .replace("https://", "")
    .replace("http://", "")
    .replace("/", "_")
)


site_folder = os.path.join(
    BASE_DIR,
    site_name
)

os.makedirs(
    site_folder,
    exist_ok=True
)


print(
    Colorate.Horizontal(
        Colors.blue_to_white,
        f"\n[+] Сайт: {input_url}",
        1
    )
)


#скачивание главной страницы
print(
    Colorate.Horizontal(
        Colors.blue_to_white,
        f"[↓] HTML: {input_url}",
        1
    )
)

try:

    resp = session.get(
        input_url,
        timeout=TIMEOUT
    )

    resp.raise_for_status()

    html = resp.text

    print(
        Colorate.Horizontal(
            Colors.blue_to_white,
            "[+] HTML получен",
            1
        )
    )

except Exception as e:

    print(
        Colorate.Horizontal(
            Colors.blue_to_white,
            f"[!] Ошибка загрузки сайта: {e}",
            1
        )
    )

    raise SystemExit(1)


soup = BeautifulSoup(
    html,
    "html.parser"
)


resources = []


for tag, attr in [
    ("link", "href"),
    ("script", "src"),
    ("img", "src"),
    ("video", "src"),
    ("audio", "src"),
    ("source", "src"),
    ("iframe", "src"),
]:

    for el in soup.find_all(tag):

        v = el.get(attr)

        if (
            v
            and valid(v)
            and not data_uri(v)
        ):
            resources.append(
                (el, attr, v)
            )


for el in soup.find_all("link"):

    rel = el.get("rel")

    if rel:

        if (
            "preload" in rel
            and el.get("as") == "font"
        ):

            v = el.get("href")

            if (
                v
                and valid(v)
                and not data_uri(v)
            ):
                resources.append(
                    (el, "href", v)
                )


inline_style_elements = []


for el in soup.find_all(True):

    style = el.get("style")

    if style:
        inline_style_elements.append(
            (el, style)
        )


css_url_pattern = re.compile(
    r'url\(\s*([\'"]?)(.*?)\1\s*\)',
    flags=re.I
)

css_import_pattern = re.compile(
    r'@import\s+(?:url\()?["\']?(.*?)["\']?\)?\s*;',
    flags=re.I
)


#обработка CSS и загрузки ресурсов из него
def css(css_text, css_base_url, dest_folder):

    def import_repl(m):

        target = m.group(1).strip()

        if (
            data_uri(target)
            or not valid(target)
        ):
            return m.group(0)

        full = urljoin(
            css_base_url,
            target
        )

        local_rel = download_save(
            full,
            dest_folder
        )

        if local_rel:
            return f'@import "{local_rel}";'

        return m.group(0)


    text = css_import_pattern.sub(
        import_repl,
        css_text
    )


    def url_repl(m):

        target = m.group(2).strip()

        if (
            data_uri(target)
            or not valid(target)
        ):
            return m.group(0)

        full = urljoin(
            css_base_url,
            target
        )

        local_rel = download_save(
            full,
            dest_folder
        )

        if local_rel:
            return f'url("{local_rel}")'

        return m.group(0)


    text = css_url_pattern.sub(
        url_repl,
        text
    )

    return text


#обработка всех найденных ресурсов
for el, attr, src in resources:

    if data_uri(src):
        continue

    full = urljoin(
        base_url,
        src
    )

    tag_name = el.name.lower()


    if (
        tag_name == "link"
        and el.get("rel")
        and (
            "stylesheet" in el.get("rel")
            or el.get("type") == "text/css"
        )
    ):

        css_text = download_text(full)

        if css_text is None:
            continue

        new_css = css(
            css_text,
            full,
            site_folder
        )

        local_rel = filename_url(full)

        if not local_rel.lower().endswith(".css"):
            local_rel += ".css"

        local_path = os.path.join(
            site_folder,
            local_rel
        )

        dir(local_path)

        with open(
            local_path,
            "w",
            encoding="utf-8"
        ) as wf:

            wf.write(new_css)

        el[attr] = os.path.relpath(
            local_path,
            site_folder
        ).replace("\\", "/")


    elif (
        tag_name == "link"
        and el.get("rel")
        and "preload" in [
            r.lower()
            for r in el.get("rel")
        ]
        and el.get("as") == "font"
    ):

        full_font = urljoin(
            base_url,
            src
        )

        local_rel = download_save(
            full_font,
            site_folder
        )

        if local_rel:
            el[attr] = local_rel


    elif tag_name in (
        "script",
        "img",
        "video",
        "source",
        "audio",
        "iframe"
    ):

        local_rel = download_save(
            full,
            site_folder
        )

        if local_rel:
            el[attr] = local_rel


#обработка встроенного CSS
for style_tag in soup.find_all("style"):

    css_text = style_tag.string or ""

    if not css_text.strip():
        continue

    new_css = css(
        css_text,
        base_url,
        site_folder
    )

    style_tag.string = new_css


#обработка inline style
for el, style in inline_style_elements:

    new_style = css(
        style,
        base_url,
        site_folder
    )

    el["style"] = new_style


#сохранение HTML
html_file = os.path.join(
    site_folder,
    "index.html"
)


with open(
    html_file,
    "w",
    encoding="utf-8"
) as f:

    f.write(str(soup))


print(
    Colorate.Horizontal(
        Colors.blue_to_white,
        f"\n[+] Сайт сохранён: {site_folder}",
        1
    )
)


#класс HTTP сервера без вывода запросов в консоль
class QuietHandler(
    http.server.SimpleHTTPRequestHandler
):

    #функция отключения вывода HTTP-запросов
    def log_message(self, format, *args):
        return


#переход в папку скачанного сайта
os.chdir(site_folder)


#запуск локального HTTP сервера
httpd = socketserver.TCPServer(
    ("0.0.0.0", PORT),
    QuietHandler
)


#путь к SSH ключу рядом со скриптом
script_dir = os.path.dirname(
    os.path.abspath(__file__)
)

ssh_key = os.path.join(
    script_dir,
    "localhost_run"
)


#проверка наличия SSH ключа
if not os.path.exists(ssh_key):

    print(
        Colorate.Horizontal(
            Colors.blue_to_white,
            "[!] SSH-ключ не найден: "
            + ssh_key,
            1
        )
    )

    raise SystemExit(1)


print(
    Colorate.Horizontal(
        Colors.blue_to_white,
        "\n[+] Запуск публичного туннеля...",
        1
    )
)


#запуск SSH туннеля
proc = subprocess.Popen(
    [
        "ssh",
        "-i",
        ssh_key,
        "-o",
        "IdentitiesOnly=yes",
        "-o",
        "StrictHostKeyChecking=no",
        "-o",
        "ExitOnForwardFailure=yes",
        "-R",
        f"80:localhost:{PORT}",
        "ssh.localhost.run"
    ],
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT,
    text=True,
    bufsize=1
)


external_link = None


#чтение и вывод всего лога SSH
for line in proc.stdout:

    line = line.strip()

    if not line:
        continue

    #выводим весь лог SSH
    print(line, flush=True)

    #поиск обычных HTTP/HTTPS ссылок
    urls = re.findall(
        r'https?://[^\s<>"\']+',
        line
    )

    for url in urls:

        url = url.rstrip(
            ".,);]}"
        )

        #не принимаем локальные адреса
        if (
            "localhost" not in url
            and "127.0.0.1" not in url
            and "0.0.0.0" not in url
        ):

            if url != external_link:

                external_link = url

                print(
                    Colorate.Horizontal(
                        Colors.blue_to_white,
                        f"\n[+] Публичная ссылка: {external_link}",
                        1
                    )
                )


#если SSH завершился без ссылки
if not external_link:

    print(
        Colorate.Horizontal(
            Colors.blue_to_white,
            "\n[!] Публичная ссылка не обнаружена.",
            1
        )
    )


#запуск сервера
httpd.serve_forever()
