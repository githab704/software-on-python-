from pathlib import Path
from pystyle import Colorate, Colors, Center
import base64, binascii, json, urllib.parse as urlp, os, sys
import re
import time
import string
import ast

try:
    import orjson, simplejson, jwt
except:
    pass


clr = lambda t: Colorate.Horizontal(Colors.purple_to_blue, t, 1)
ctr = lambda t: Center.XCenter(t)
cls = lambda: os.system('cls' if os.name == 'nt' else 'clear')


#банер
baner = r'''
██▄   ▄███▄   ▄█▄    ████▄ ██▄   ▄███▄   █▄▄▄▄
█  █  █▀   ▀  █▀ ▀▄  █   █ █  █  █▀   ▀  █  ▄▀
█   █ ██▄▄    █   ▀  █   █ █   █ ██▄▄    █▀▀▌
█  █  █▄   ▄▀ █▄  ▄▀ ▀████ █  █  █▄   ▄▀ █  █
███▀  ▀███▀   ▀███▀        ███▀  ▀███▀     █
                                              ▀
'''


# кодирование
N = [
    'b64.encode',
    'base64.b64decode',
    'base64.urlsafe_b64encode',
    'base64.urlsafe_b64decode',
    'std.b64encode',
    'std.b64decode',
    'binascii.hexlify',
    'binascii.unhexlify',
    'window.btoa',
    'window.atob',
    'Buffer.from',
    'Go EncodeToString',
    'Go DecodeString',
    'Rust base64::encode',
    'Rust base64::decode',
    'urllib.parse.quote',
    'urllib.parse.unquote',
    'urllib.parse.quote_plus',
    'url.unquote+',
    'urllib.parse.urlencode',
    'encodeURI',
    'decodeURI',
    'encodeURIComponent',
    'decodeURIComponent',
    'escape',
    'url.QueryEscape',
    'url.QueryUnescape',
    'url.PathEscape',
    'url.PathUnescape',
    'urlencoding::encode',
    'json.dumps',
    'json.loads',
    'orjson.dumps',
    'orjson.loads',
    'simplejson.dumps',
    'json.Marshal',
    'json.Unmarshal',
    'serde_json::to_string',
    'serde_json::from_str',
    'serde_json::to_value',
    'jwt.encode',
    'jwt.decode',
    'jsonwebtoken.sign',
    'jsonwebtoken.verify',
    'jwt.NewWithClaims'
]


# декодирование
FM = {
    'b64.encode': ('enc', lambda s: base64.b64encode(s.encode()).decode()),
    'base64.b64decode': ('dec', lambda s: base64.b64decode(s, validate=True).decode()),
    'base64.urlsafe_b64encode': ('enc', lambda s: base64.urlsafe_b64encode(s.encode()).decode()),
    'base64.urlsafe_b64decode': ('dec', lambda s: base64.urlsafe_b64decode(s).decode()),
    'std.b64encode': ('enc', lambda s: base64.standard_b64encode(s.encode()).decode()),
    'std.b64decode': ('dec', lambda s: base64.standard_b64decode(s, validate=True).decode()),
    'binascii.hexlify': ('enc', lambda s: binascii.hexlify(s.encode()).decode()),
    'binascii.unhexlify': ('dec', lambda s: binascii.unhexlify(s).decode(errors='strict')),
    'window.btoa': ('enc', lambda s: base64.b64encode(s.encode()).decode()),
    'window.atob': ('dec', lambda s: base64.b64decode(s, validate=True).decode()),
    'Buffer.from': ('dec', lambda s: base64.b64decode(s, validate=True).decode()),
    'Go EncodeToString': ('enc', lambda s: base64.b64encode(s.encode()).decode()),
    'Go DecodeString': ('dec', lambda s: base64.b64decode(s, validate=True).decode()),
    'Rust base64::encode': ('enc', lambda s: base64.b64encode(s.encode()).decode()),
    'Rust base64::decode': ('dec', lambda s: base64.b64decode(s, validate=True).decode()),
    'urllib.parse.quote': ('enc', lambda s: urlp.quote(s, safe='')),
    'urllib.parse.unquote': ('dec', lambda s: urlp.unquote(s)),
    'urllib.parse.quote_plus': ('enc', lambda s: urlp.quote_plus(s)),
    'url.unquote+': ('dec', lambda s: urlp.unquote_plus(s)),
    'urllib.parse.urlencode': (
        'enc',
        lambda s: urlp.urlencode(
            dict(p.split('=', 1) for p in s.split('&'))
        )
    ),
    'encodeURI': (
        'enc',
        lambda s: urlp.quote(
            s,
            safe=":/?#[]@!$&'()*+,;="
        )
    ),
    'decodeURI': ('dec', lambda s: urlp.unquote(s)),
    'encodeURIComponent': ('enc', lambda s: urlp.quote(s, safe='')),
    'decodeURIComponent': ('dec', lambda s: urlp.unquote(s)),
    'escape': (
        'enc',
        lambda s: ''.join('%{:02X}'.format(ord(c)) for c in s)
    ),
    'url.QueryEscape': ('enc', lambda s: urlp.quote(s)),
    'url.QueryUnescape': ('dec', lambda s: urlp.unquote(s)),
    'url.PathEscape': ('enc', lambda s: urlp.quote(s)),
    'url.PathUnescape': ('dec', lambda s: urlp.unquote(s)),
    'urlencoding::encode': ('enc', lambda s: urlp.quote_plus(s)),
    'json.dumps': (
        'enc',
        lambda s: json.dumps(ast.literal_eval(s))
    ),
    'json.loads': (
        'dec',
        lambda s: json.dumps(
            json.loads(s),
            ensure_ascii=False
        )
    ),
    'orjson.dumps': (
        'enc',
        lambda s: orjson.dumps(ast.literal_eval(s)).decode()
        if 'orjson' in sys.modules else s
    ),
    'orjson.loads': (
        'dec',
        lambda s: orjson.dumps(
            orjson.loads(s)
        ).decode()
        if 'orjson' in sys.modules else s
    ),
    'simplejson.dumps': (
        'enc',
        lambda s: simplejson.dumps(
            ast.literal_eval(s)
        )
        if 'simplejson' in sys.modules else s
    ),
    'json.Marshal': (
        'enc',
        lambda s: json.dumps(ast.literal_eval(s))
    ),
    'json.Unmarshal': (
        'dec',
        lambda s: json.dumps(
            json.loads(s),
            ensure_ascii=False
        )
    ),
    'serde_json::to_string': (
        'enc',
        lambda s: json.dumps(ast.literal_eval(s))
    ),
    'serde_json::from_str': (
        'dec',
        lambda s: json.dumps(
            json.loads(s),
            ensure_ascii=False
        )
    ),
    'serde_json::to_value': (
        'dec',
        lambda s: json.dumps(
            json.loads(s),
            ensure_ascii=False
        )
    ),
    'jwt.encode': (
        'enc',
        lambda s: jwt.encode(
            ast.literal_eval(s),
            'key',
            algorithm='HS256'
        )
        if 'jwt' in sys.modules else s
    ),
    'jwt.decode': (
        'dec',
        lambda s: jwt.decode(
            s,
            'key',
            algorithms=['HS256']
        )
        if 'jwt' in sys.modules else s
    ),
    'jsonwebtoken.sign': (
        'enc',
        lambda s: jwt.encode(
            ast.literal_eval(s),
            'key',
            algorithm='HS256'
        )
        if 'jwt' in sys.modules else s
    ),
    'jsonwebtoken.verify': (
        'dec',
        lambda s: jwt.decode(
            s,
            'key',
            algorithms=['HS256']
        )
        if 'jwt' in sys.modules else s
    ),
    'jwt.NewWithClaims': (
        'enc',
        lambda s: jwt.encode(
            ast.literal_eval(s),
            'key',
            algorithm='HS256'
        )
        if 'jwt' in sys.modules else s
    )
}


# Создание рамки для списка строк
def box(lines, w=32):
    top = f'┌{"─" * (w - 2)}┐'
    bot = f'└{"─" * (w - 2)}┘'
    body = [
        f'│ {ln.ljust(w - 4)} │'
        for ln in lines
    ]
    return [top, *body, bot]


# Вывод всех методов
def method():
    print(clr(ctr(baner)))
    print(clr(ctr('[ by: @DreamDolphin ]\n')))

    frames = [
        box(
            [
                f'{i+j+1:2}. {N[i+j]}'
                for j in range(5)
            ]
        )
        for i in range(0, 45, 5)
    ]

    for row in range(0, 9, 3):
        for r in range(len(frames[0])):
            line = '  '.join(
                frames[row+k][r]
                for k in range(3)
            )
            print(clr(ctr(line)))
        print()


# постоянное декодирование
def dec(fn, s):
    cur = s

    while True:
        try:
            nxt = fn(cur)

            if nxt == cur:
                break

            print(
                clr(
                    ' [ + ] еще слой декодирую…'
                )
            )

            cur = nxt

        except:
            break

    return cur


# Проверяет насколько результат похож на нормальный текст
def text_score(text):
    if not isinstance(text, str) or not text:
        return 0

    length = len(text)

    printable = sum(
        c in string.printable or ord(c) >= 32
        for c in text
    )

    printable_ratio = printable / length

    score = printable_ratio * 45

    if printable_ratio > 0.98:
        score += 20

    if printable_ratio > 0.995:
        score += 10

    words = re.findall(
        r'[A-Za-zА-Яа-яЁё]{2,}',
        text
    )

    if len(words) >= 2:
        score += min(len(words) * 2, 15)

    if re.search(
        r'[А-Яа-яЁё]',
        text
    ):
        score += 5

    if re.search(
        r'\b(the|this|that|function|import|from|class|def|return)\b',
        text,
        re.IGNORECASE
    ):
        score += 5

    return min(score, 100)


# Проверяет JSON и добавляет баллы за настоящую структуру
def json_score(text):
    if not isinstance(text, str):
        return 0

    try:
        obj = json.loads(text)

        score = 35

        if isinstance(obj, dict):
            score += 25

        elif isinstance(obj, list):
            score += 20

        elif isinstance(obj, (str, int, float, bool)):
            score += 5

        return min(score, 60)

    except:
        return 0


# Проверяет HEX-строку
def hex_score(text):
    if not text:
        return 0

    clean = text.strip()

    if len(clean) < 4:
        return 0

    if len(clean) % 2 != 0:
        return 0

    if not re.fullmatch(
        r'[0-9a-fA-F]+',
        clean
    ):
        return 0

    return 30


# Проверяет Base64-структуру
def base64_score(text):
    clean = ''.join(text.split())

    if len(clean) < 8:
        return 0

    if len(clean) % 4 != 0:
        return 0

    if not re.fullmatch(
        r'[A-Za-z0-9+/]*={0,2}',
        clean
    ):
        return 0

    try:
        raw = base64.b64decode(
            clean,
            validate=True
        )

        if not raw:
            return 0

        score = 25

        printable = sum(
            32 <= b < 127 or b in (9, 10, 13)
            for b in raw
        )

        ratio = printable / len(raw)

        if ratio > 0.90:
            score += 40

        elif ratio > 0.70:
            score += 25

        elif ratio > 0.50:
            score += 10

        return min(score, 65)

    except:
        return 0


# Проверяет URL-кодирование
def url_score(text):
    if not text:
        return 0

    matches = re.findall(
        r'%[0-9A-Fa-f]{2}',
        text
    )

    if not matches:
        return 0

    score = min(
        len(matches) * 8,
        35
    )

    decoded = urlp.unquote(text)

    if decoded != text:
        score += text_score(decoded) * 0.35

    return min(score, 60)


# Проверяет JWT-подобную структуру
def jwt_score(text):
    parts = text.strip().split('.')

    if len(parts) != 3:
        return 0

    score = 25

    try:
        for part in parts[:2]:
            padded = part + '=' * (
                -len(part) % 4
            )

            decoded = base64.urlsafe_b64decode(
                padded
            )

            json.loads(decoded.decode())

            score += 25

        return min(score, 75)

    except:
        return 0


# Определяет насколько результат декодирования правдоподобен
def result_score(original, result, name):
    if not result or result == original:
        return 0

    score = 0

    score += text_score(result)

    score += json_score(result)

    low = name.lower()

    if 'b64decode' in low:
        score += base64_score(original)

    if 'unhexlify' in low:
        score += hex_score(original)

    if (
        'unquote' in low
        or 'decodeuri' in low
        or 'decodeuricomponent' in low
    ):
        score += url_score(original)

    if (
        'jwt.decode' in low
        or 'jsonwebtoken.verify' in low
    ):
        score += jwt_score(original)

    if result.lstrip().startswith(
        ('{', '[')
    ):
        score += 15

    if re.search(
        r'(import |from |def |class |function |#include |package )',
        result
    ):
        score += 20

    return min(score, 150)


# Проверяет одну decode функцию и возвращает результат и оценку
def test_decoder(name, original):
    if name not in FM:
        return None, 0

    kind, fn = FM[name]

    if kind != 'dec':
        return None, 0

    try:
        result = fn(original)

        if not isinstance(result, str):
            result = str(result)

        score = result_score(
            original,
            result,
            name
        )

        return result, score

    except:
        return None, 0


# Показывает анимацию ожидания в одной строке
def wait_animation(seconds=3):
    end = time.time() + seconds
    dots = 1

    while time.time() < end:
        print(
            '\r' +
            clr(
                '[ i ] Подождите' + '.' * dots
            ),
            end='',
            flush=True
        )

        time.sleep(1)

        dots += 1

        if dots > 3:
            dots = 1

    print('\r' + ' ' * 60 + '\r', end='')


# Автоматически определяет наиболее вероятную кодировку
def detect_encoding(data):
    candidates = []

    for number, name in enumerate(N, 1):
        if name not in FM:
            continue

        kind, fn = FM[name]

        if kind != 'dec':
            continue

        result, score = test_decoder(
            name,
            data
        )

        if result is None:
            continue

        if score <= 0:
            continue

        candidates.append(
            (
                score,
                number,
                name,
                result
            )
        )

    if not candidates:
        return None

    candidates.sort(
        key=lambda x: x[0],
        reverse=True
    )

    best = candidates[0]

    if len(candidates) > 1:
        second = candidates[1]

        if (
            best[0] - second[0] < 8
            and best[0] < 70
        ):
            return None

    confidence = min(
        int(best[0] / 1.35),
        99
    )

    return {
        'score': best[0],
        'number': best[1],
        'name': best[2],
        'result': best[3],
        'confidence': confidence
    }


# Запускает автоматический поиск кодировки
def auto_detect(data):
    print(
        clr(
            '\n[ i ] Анализирую содержимое...'
        )
    )

    wait_animation(3)

    result = detect_encoding(data)

    if not result:
        print(
            clr(
                '[ - ] Не удалось определить кодировку с достаточной уверенностью.'
            )
        )
        return None

    print(
        clr(
            f'[ + ] Вероятная кодировка: {result["name"]}'
        )
    )

    print(
        clr(
            f'[ + ] Номер функции: {result["number"]}'
        )
    )

    print(
        clr(
            f'[ + ] Уверенность: {result["confidence"]}%'
        )
    )

    return result


# Выбор файла из входной папки
def choose_file():
    input_dir = Path(__file__).parent / 'input'

    input_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    files = [
        f for f in input_dir.iterdir()
        if f.is_file()
    ]

    if not files:
        print(
            clr(
                '\n[ - ] В папке input нет файлов.'
            )
        )

        print(
            clr(
                '[ i ] Положите свой файл в папку input'
            )
        )

        print(
            clr(
                f'[ i ] Папка: {input_dir}'
            )
        )

        return None

    print(
        clr(
            '\n[ i ] Выберите файл:\n'
        )
    )

    for i, file in enumerate(files, 1):
        print(
            clr(
                f'[ {i:2} ] {file.name}'
            )
        )

    while True:
        choice = input(
            clr(
                '\nНомер файла: '
            )
        ).strip()

        if not choice.isdigit():
            print(
                clr(
                    '[!] Введите номер файла.'
                )
            )
            continue

        number = int(choice)

        if 1 <= number <= len(files):
            return files[number - 1]

        print(
            clr(
                '[!] Неверный номер.'
            )
        )


# Создаёт имя результата после encode,decode
def result_path(source, action):
    output_dir = Path(__file__).parent / 'output'

    output_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    return output_dir / (
        f'{action}_{source.name}'
    )


# Обрабатывает строку через выбранную функцию
def process_string(name, kind, fn):
    txt = input(
        clr(
            'Строка  '
        )
    )

    if kind == 'enc':
        try:
            layer = int(
                input(
                    clr(
                        'Слои? (Enter=1)  '
                    )
                ) or 1
            )
        except ValueError:
            layer = 1

        res = txt

        for _ in range(layer):
            res = fn(res)

    else:
        res = dec(
            fn,
            txt
        )

    print(
        '\n' +
        res +
        '\n'
    )


# Обрабатывает файл через выбранную функцию
def process_file(name, kind, fn, number):
    path = choose_file()

    if path is None:
        return

    try:
        data = path.read_text(
            encoding='utf-8',
            errors='ignore'
        )
    except Exception as e:
        print(
            clr(
                f'[ - ] Ошибка чтения файла: {e}'
            )
        )
        return

    if kind == 'enc':
        try:
            layers = int(
                input(
                    clr(
                        'Слои? (Enter=1) › '
                    )
                ) or 1
            )
        except ValueError:
            layers = 1

        result = data

        for _ in range(layers):
            result = fn(result)

        dst = result_path(
            path,
            f'encode_{number}'
        )

    else:
        result = dec(
            fn,
            data
        )

        dst = result_path(
            path,
            f'decode_{number}'
        )

    try:
        dst.write_text(
            result,
            encoding='utf-8'
        )

        print(
            clr(
                f'\n[ + ] Результат: {dst}'
            )
        )

    except Exception as e:
        print(
            clr(
                f'[ - ] Ошибка записи: {e}'
            )
        )


# Обрабатывает выбранную функцию
def handle_function(number):
    name = N[number - 1]
    kind, fn = FM[name]

    print(
        clr(
            f'\n>>> {name}'
        )
    )

    print(
        clr(
            '[ 1 ] строка'
        )
    )

    print(
        clr(
            '[ 2 ] файл'
        )
    )

    mode = input(
        clr(
            'Выбор  '
        )
    ).strip()

    if mode == '1':
        process_string(
            name,
            kind,
            fn
        )

    elif mode == '2':
        process_file(
            name,
            kind,
            fn,
            number
        )

    else:
        print(
            clr(
                '[!] 1 или 2'
            )
        )


# Запрашивает автоматический поиск перед decode
def decode_mode():
    print(
        clr(
            '\n[ i ] Если не знаете кодировку вашего файла, то можете узнать:'
        )
    )

    print(
        clr(
            '[ 1 ] хочу узнать'
        )
    )

    print(
        clr(
            '[ 2 ] я уже знаю'
        )
    )

    while True:
        choice = input(
            clr(
                'Выбор  '
            )
        ).strip()

        if choice in ('1', '2'):
            return choice

        print(
            clr(
                '[!] Выберите 1 или 2.'
            )
        )

# Запускает декодирование с автоопределением
def decode_auto():
    path = choose_file()

    if path is None:
        return

    try:
        data = path.read_text(
            encoding='utf-8',
            errors='ignore'
        )
    except Exception as e:
        print(
            clr(
                f'[ - ] Ошибка чтения файла: {e}'
            )
        )
        return

    result = auto_detect(data)

    if result is None:
        return

    name = result['name']

    kind, fn = FM[name]

    decoded = dec(
        fn,
        data
    )

    dst = result_path(
        path,
        f'decode_{result["number"]}'
    )

    try:
        dst.write_text(
            decoded,
            encoding='utf-8'
        )

        print(
            clr(
                f'[ + ] Декодированный файл: {dst}'
            )
        )

    except Exception as e:
        print(
            clr(
                f'[ - ] Ошибка записи: {e}'
            )
        )


# меню 
def main():
    cls()
    method()

    while True:
        num = input(
            clr(
                '\nНомер 1-45  ENTER выход : '
            )
        ).strip()

        if not num:
            break

        if (
            not num.isdigit()
            or not 1 <= int(num) <= 45
        ):
            print(
                clr(
                    'Введите цифру 1-45 : '
                )
            )
            continue

        number = int(num)

        name = N[number - 1]

        kind, fn = FM[name]

        if kind == 'dec':
            choice = decode_mode()

            if choice == '1':
                decode_auto()
                input(
                    clr(
                        '\n[Enter] для продолжения...'
                    )
                )
                cls()
                method()
                continue

        handle_function(number)

        input(
            clr(
                '\n[Enter] для продолжения...'
            )
        )

        cls()
        method()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass