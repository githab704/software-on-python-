import os
import string
import itertools
import zipfile
import subprocess
import io
from pystyle import Colors, Colorate, Center

try:
    import msoffcrypto
except:
    pass

color = Colors.green_to_blue

# Очистка экрана
def clear():
    os.system("clear")

# Пауза до нажатия Enter
def pause():
    input(Colorate.Horizontal(color, "\nНажмите Enter для возврата в меню..."))

# Отображение баннера
def baner():
    print(Colorate.Horizontal(color, Center.XCenter("""
▄▄▄▄· ▄▄▄  ▄• ▄▌▄▄▄▄▄·▄▄▄      ▄▄▄  .▄▄ · ▄▄▄ .
▐█ ▀█▪▀▄ █·█▪██▌•██  ▐▄▄·▪     ▀▄ █·▐█ ▀. ▀▄.▀·
▐█▀▀█▄▐▀▀▄ █▌▐█▌ ▐█.▪██▪  ▄█▀▄ ▐▀▀▄ ▄▀▀▀█▄▐▀▀▪▄
██▄▪▐█▐█•█▌▐█▄█▌ ▐█▌·██▌.▐█▌.▐▌▐█•█▌▐█▄▪▐█▐█▄▄▌
·▀▀▀▀ .▀  ▀ ▀▀▀  ▀▀▀ ▀▀▀  ▀█▄▀▪.▀  ▀ ▀▀▀▀  ▀▀▀
""")))
    print(Center.XCenter(Colorate.Horizontal(color, "[ by @DreamDolphin ]")))

# Сохранение пароля
def password(password, target):
    with open("found.txt", "a") as f:
        f.write(f"[+] {target} | Пароль: {password}\n")

# Генератор комбинаций
def gen_combo(chars, min_len, max_len):
    for length in range(min_len, max_len + 1):
        for combo in itertools.product(chars, repeat=length):
            yield "".join(combo)

# Список файлов в папке
def direct_files(folder):
    files = []
    if os.path.isdir(folder):
        for i, name in enumerate(os.listdir(folder), 1):
            files.append(os.path.join(folder, name))
            print(f"[{i}] {name}")
    return files

# Выбор файла
def select_file(folder, prompt):
    files = direct_files(folder)
    if not files:
        print(Colorate.Horizontal(color, f"[+] В папке {folder} нет файлов."))
        pause()
        return None
    choice = input(Colorate.Horizontal(color, prompt))
    try:
        idx = int(choice) - 1
        return files[idx]
    except:
        print(Colorate.Horizontal(color, "[+] Неверный выбор."))
        pause()
        return None

# Выбор словаря
def pick_wordlist():
    return select_file("wordlists", "Выберите словарь: ")

# Выбор целевого файла
def pick_target():
    return select_file("targets", "Выберите файл для подбора: ")

# Ввод длины пароля
def input_lengths():
    try:
        min_len = int(input(Colorate.Horizontal(color, "Мин. длина (1–20): ")))
        max_len = int(input(Colorate.Horizontal(color, "Макс. длина (1–20): ")))
        if min_len < 1 or max_len > 20 or min_len > max_len:
            print(Colorate.Horizontal(color, "[+] Неверные значения."))
            pause()
            return None, None
        return min_len, max_len
    except:
        print(Colorate.Horizontal(color, "[+] Неверный ввод."))
        pause()
        return None, None

# Взлом ZIP
def crack_zip(path, wordlist):
    try:
        with zipfile.ZipFile(path) as z:
            for pwd in wordlist:
                pwd = pwd.strip()
                print(f"\rПодбор пароля: {pwd}", end="", flush=True)
                try:
                    test_file = z.namelist()[0]
                    z.open(test_file, pwd=bytes(pwd, "utf-8")).read(1)
                    print(f"\n[+] Пароль найден: {pwd}")
                    password(pwd, path)
                    pause()
                    return
                except:
                    continue
            print("\n[+] Пароль не найден.")
            pause()
    except Exception as e:
        print(f"[+] Ошибка: {e}")
        pause()

# Взлом PDF (требуется qpdf)
def crack_pdf(path, wordlist):
    for pwd in wordlist:
        pwd = pwd.strip()
        print(f"\rПодбор пароля: {pwd}", end="", flush=True)
        result = subprocess.run(
            ["qpdf", f"--password={pwd}", "--check", path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        if result.returncode == 0:
            print(f"\n[+] Пароль найден: {pwd}")
            password(pwd, path)
            pause()
            return
    print("\n[+] Пароль не найден.")
    pause()

# Взлом 7z (требуется 7zz)
def crack_7z(path, wordlist):
    for pwd in wordlist:
        pwd = pwd.strip()
        print(f"\rПодбор пароля: {pwd}", end="", flush=True)
        cmd = ["7zz", "t", path, f"-p{pwd}"]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if b"Everything is Ok" in result.stdout:
            print(f"\n[+] Пароль найден: {pwd}")
            password(pwd, path)
            pause()
            return
    print("\n[+] Пароль не найден.")
    pause()

# Взлом DOCX/XLSX (требуется msoffcrypto)
def crack_docx(path, wordlist):
    for pwd in wordlist:
        pwd = pwd.strip()
        print(f"\rПодбор пароля: {pwd}", end="", flush=True)
        try:
            with open(path, "rb") as f:
                office = msoffcrypto.OfficeFile(f)
                office.load_key(password=pwd)
                office.decrypt(io.BytesIO())
                print(f"\n[+] Пароль найден: {pwd}")
                password(pwd, path)
                pause()
                return
        except:
            continue
    print("\n[+] Пароль не найден.")
    pause()

# Смена цвета
def change_color():
    global color
    
    colors_map = {  
        "1": ("red_to_blue", Colors.red_to_blue),  
        "3": ("green_to_yellow", Colors.green_to_yellow),  
        "4": ("blue_to_cyan", Colors.blue_to_cyan),  
        "6": ("purple_to_red", Colors.purple_to_red),  
        "7": ("cyan_to_green", Colors.cyan_to_green),  
    }  
    
    clear()  
    print()  
    
    for key, (name, gradient) in colors_map.items():  
        print(Colorate.Horizontal(gradient, Center.XCenter(f"[{key}] ➤ {name}")))  
    
    print()  
    choice = input(Colorate.Horizontal(color, "Выбор цвета > "))  
    
    if choice in colors_map:  
        color = colors_map[choice][1]  
        print(Colorate.Horizontal(color, "\n[+] Цвет применён"))  
    else:  
        print(Colorate.Horizontal(color, "\n[+] Неверный выбор"))  
    
    pause()

# Меню
def menu():
    while True:
        clear()
        baner()
        
        left = [
            "┌────────────────────────────────────────┐",
            "│ [1] По словарю (из папки wordlists)   │",
            "│ [2] Английские буквы                  │",
            "│ [3] Русские буквы                     │",
            "└────────────────────────────────────────┘",
        ]
        right = [
            "┌────────────────────────────────────────┐",
            "│ [4] Только цифры                      │",
            "│ [5] Английские + цифры                │",
            "│ [6] Русские + цифры                   │",
            "└────────────────────────────────────────┘",
        ]
        
        print()
        for i in range(len(left)):
            print(Colorate.Horizontal(color, Center.XCenter(left[i].ljust(50) + "    " + right[i])))
        
        extra = [
            "┌────────────────────────────────────────┐",
            "│ [7] Сменить цвет                      │",
            "│ [8] Выход                             │",
            "└────────────────────────────────────────┘",
        ]
        for line in extra:
            print(Colorate.Horizontal(color, Center.XCenter(line)))
        
        opt = input(Colorate.Horizontal(color, "\nВыбор режима > "))
        
        if opt == "7":
            change_color()
            continue
        if opt == "8":
            print(Colorate.Horizontal(color, "\nВыход..."))
            break
        
        target = pick_target()
        if not target:
            continue
        ext = target.split(".")[-1].lower()
        
        if opt == "1":
            wl = pick_wordlist()
            if not wl:
                continue
            wordlist_data = open(wl, errors="ignore").read().splitlines()
        elif opt == "2":
            min_len, max_len = input_lengths()
            if min_len is None:
                continue
            wordlist_data = gen_combo(string.ascii_letters, min_len, max_len)
        elif opt == "3":
            min_len, max_len = input_lengths()
            if min_len is None:
                continue
            wordlist_data = gen_combo("абвгдеёжзийклмнопрстуфхцчшщъыьэюя", min_len, max_len)
        elif opt == "4":
            min_len, max_len = input_lengths()
            if min_len is None:
                continue
            wordlist_data = gen_combo(string.digits, min_len, max_len)
        elif opt == "5":
            min_len, max_len = input_lengths()
            if min_len is None:
                continue
            wordlist_data = gen_combo(string.ascii_letters + string.digits, min_len, max_len)
        elif opt == "6":
            min_len, max_len = input_lengths()
            if min_len is None:
                continue
            wordlist_data = gen_combo("абвгдеёжзийклмнопрстуфхцчшщъыьэюя0123456789", min_len, max_len)
        else:
            print(Colorate.Horizontal(color, "[+] Неверный ввод."))
            pause()
            continue
        
        if ext == "zip":
            crack_zip(target, wordlist_data)
        elif ext == "pdf":
            crack_pdf(target, wordlist_data)
        elif ext == "7z":
            crack_7z(target, wordlist_data)
        elif ext in ["docx", "xlsx"]:
            crack_docx(target, wordlist_data)
        else:
            print(Colorate.Horizontal(color, "[+] Тип файла не поддерживается."))
            pause()

if __name__ == "__main__":
    menu()