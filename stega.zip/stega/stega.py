import os
import sys
import base64
from pystyle import Colorate, Colors

PHOTO_DIR = "photo"
RESULT_DIR = "result"
MARKER = "###SWAGA###"

#очистка терминала от мусора 
def clear():
    os.system("cls" if os.name == "nt" else "clear")
#функция что бы спрятать текст и проверка
def steg():
    print(Colorate.Horizontal(Colors.rainbow, "[ Спрятать текст в фото ]\n"))

    files = [f for f in os.listdir(PHOTO_DIR) if f.endswith("")]
    if not files:
        print(Colorate.Horizontal(Colors.rainbow, "[!] Нет файлов .png или .jpg в папке photo/"))
        input(Colorate.Horizontal(Colors.rainbow, "\n[Enter] для возврата в меню..."))
        return

    for i, f in enumerate(files, 1):
        print(Colorate.Horizontal(Colors.rainbow, f"{i}) {f}"))

    num = input(Colorate.Horizontal(Colors.rainbow, "\nВведите номер фото: "))
    if not num.isdigit() or int(num) not in range(1, len(files)+1):
        return

    filename = files[int(num)-1]
    path = os.path.join(PHOTO_DIR, filename)

    text = input(Colorate.Horizontal(Colors.rainbow, "\nВведите текст для встраивания: "))
    with open(path, "ab") as f:
        f.write((MARKER + text).encode("utf-8"))

    os.makedirs(RESULT_DIR, exist_ok=True)
    os.rename(path, os.path.join(RESULT_DIR, filename))
    print(Colorate.Horizontal(Colors.rainbow, f"\n[ + ] Текст успешно спрятан в {filename}"))
    input(Colorate.Horizontal(Colors.rainbow, "\n[Enter] для возврата в меню..."))

#функция что бы извлечь текст из фото и проверка
def extract():
    print(Colorate.Horizontal(Colors.rainbow, "[ Извлечь текст из фото ]\n"))

    files = [f for f in os.listdir(RESULT_DIR) if f.endswith("")]
    if not files:
        print(Colorate.Horizontal(Colors.rainbow, "[!] Нет файлов .png или .jpg в папке result/"))
        input(Colorate.Horizontal(Colors.rainbow, "\n[Enter] для возврата в меню..."))
        return

    for i, f in enumerate(files, 1):
        print(Colorate.Horizontal(Colors.rainbow, f"{i}) {f}"))

    num = input(Colorate.Horizontal(Colors.rainbow, "\nВведите номер фото: "))
    if not num.isdigit() or int(num) not in range(1, len(files)+1):
        return

    filename = files[int(num)-1]
    path = os.path.join(RESULT_DIR, filename)

    try:
        with open(path, "rb") as f:
            data = f.read()

        marker_pos = data.find(MARKER.encode("utf-8"))
        if marker_pos != -1:
            text = data[marker_pos+len(MARKER):].decode("utf-8", errors="replace")
            print(Colorate.Horizontal(Colors.rainbow, f"\n[ + ] Извлечённый текст (из {filename}):\n{text}"))
        else:
            print(Colorate.Horizontal(Colors.rainbow, "[ ! ] Маркер не найден — показываю хвост файла (последние 512 байт):\n"))
            tail = data[-512:]
            print(Colorate.Horizontal(Colors.rainbow, "[Raw as UTF-8 (replace)]:\n" + tail.decode("utf-8", errors="replace")))
            print(Colorate.Horizontal(Colors.rainbow, "\n[Base64]:\n" + base64.b64encode(tail).decode()))
            print(Colorate.Horizontal(Colors.rainbow, "\n[Hex]:\n" + tail.hex()))

    except Exception as e:
        print(Colorate.Horizontal(Colors.rainbow, f"[ - ] Ошибка при извлечении: {e}"))

    input(Colorate.Horizontal(Colors.rainbow, "\n[Enter] для возврата в меню..."))

#главное меню скрипта и вызов функций == 
def menu():
    while True:
        clear()
        print(Colorate.Horizontal(Colors.rainbow, r"""

 ░▒▓███████▓▒░▒▓████████▓▒░▒▓████████▓▒░▒▓██████▓▒░
░▒▓█▓▒░         ░▒▓█▓▒░   ░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░
░▒▓█▓▒░         ░▒▓█▓▒░   ░▒▓█▓▒░     ░▒▓█▓▒░
 ░▒▓██████▓▒░   ░▒▓█▓▒░   ░▒▓██████▓▒░░▒▓█▓▒▒▓███▓▒░
       ░▒▓█▓▒░  ░▒▓█▓▒░   ░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░
       ░▒▓█▓▒░  ░▒▓█▓▒░   ░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░
░▒▓███████▓▒░   ░▒▓█▓▒░   ░▒▓████████▓▒░▒▓██████▓▒░
                  
                                                     
[ by: @DreamDolphin ]
"""))

        print(Colorate.Horizontal(Colors.rainbow, """
[ 1 ] Спрятать текст в фото
[ 2 ] Извлечь текст из фото
[ 3 ] Выйти
"""))

        choice = input(Colorate.Horizontal(Colors.rainbow, "Выберите действие: "))
        if choice == "1":
            steg()
        elif choice == "2":
            extract()
        elif choice == "3":
            sys.exit(0)

if __name__ == "__main__":
    os.makedirs(PHOTO_DIR, exist_ok=True)
    os.makedirs(RESULT_DIR, exist_ok=True)
    menu()