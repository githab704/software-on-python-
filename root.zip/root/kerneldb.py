kernel_exploits = {
    "3.4": [
        {"cve": "CVE-2013-2094", "name": "perf_swevent exploit", "desc": "Privilege escalation via perf_event_open"},
        {"cve": "CVE-2014-3153", "name": "Towelroot/Futex bug", "desc": "Race condition in futex syscall"}
    ],
    "3.10": [
        {"cve": "CVE-2015-3636", "name": "Ping of Death", "desc": "ICMPv6 out-of-bounds memory write"},
        {"cve": "CVE-2016-0728", "name": "key_retain exploit", "desc": "Reference leak in keyrings subsystem"},
        {"cve": "CVE-2016-5195", "name": "Dirty COW", "desc": "Race condition in copy-on-write handling"}
    ],
    "3.18": [
        {"cve": "CVE-2016-6786", "name": "Use-after-free netlink", "desc": "UAF in netlink in Android kernels"},
        {"cve": "CVE-2016-6787", "name": "Binder vulnerability", "desc": "Improper locking in binder driver"}
    ],
    "4.4": [
        {"cve": "CVE-2017-11176", "name": "Futex requeue exploit", "desc": "Race condition in requeue_pi"},
        {"cve": "CVE-2017-1000112", "name": "DCCP exploit", "desc": "Double-free in DCCP socket code"}
    ],
    "4.9": [
        {"cve": "CVE-2018-5333", "name": "AF_PACKET heap out-of-bounds", "desc": "Buffer overwrite in packet sockets"},
        {"cve": "CVE-2019-2215", "name": "Binder UAF (Project Zero)", "desc": "UAF in Android’s binder driver"}
    ],
    "4.14": [
        {"cve": "CVE-2020-0423", "name": "Binder double-free", "desc": "Memory corruption in binder driver"},
        {"cve": "CVE-2020-14386", "name": "IPv6 socket OOB", "desc": "OOB write via IPv6 socket options"}
    ],
    "4.19": [
        {"cve": "CVE-2021-31916", "name": "seq_file exploit", "desc": "Out-of-bounds read in seq_file"},
        {"cve": "CVE-2021-3493", "name": "OverlayFS exploit", "desc": "LPE via mount namespace on Ubuntu/Android"}
    ],
    "5.4": [
        {"cve": "CVE-2021-22555", "name": "Netfilter UAF", "desc": "Use-after-free in netfilter syscall"},
        {"cve": "CVE-2021-26708", "name": "AF_VSOCK race condition", "desc": "Race in socket creation"}
    ],
    "5.10": [
        {"cve": "CVE-2022-0185", "name": "FS context heap overflow", "desc": "Container escape via fscontext"},
        {"cve": "CVE-2022-0847", "name": "Dirty Pipe", "desc": "Privilege escalation in pipe buffer overwrite"}
    ]
}
kernel_exploits.update({

    "3.0": [
        {"cve": "CVE-2012-0056", "name": "ptrace kernel mem read", "desc": "Leak kernel data via /proc/<pid>/mem"},
        {"cve": "CVE-2011-1485", "name": "ioctl crash", "desc": "Invalid ioctl in video driver"}
    ],

    "3.8": [
        {"cve": "CVE-2013-6282", "name": "Put_user NULL check bypass", "desc": "Improper validation in put_user()"},
        {"cve": "CVE-2013-2596", "name": "Vulnerability in ashmem", "desc": "Race in Android shared memory"}
    ],

    "3.18": [
        {"cve": "CVE-2017-13218", "name": "ashmem FUSE exploit", "desc": "Privilege escalation via /dev/fuse"},
        {"cve": "CVE-2017-13220", "name": "Memory corruption in ion", "desc": "UAF via ION subsystem"}
    ],

    "4.1": [
        {"cve": "CVE-2017-7308", "name": "AF_PACKET overflow", "desc": "Kernel heap overflow via packet sockets"},
        {"cve": "CVE-2016-8655", "name": "Race in packet_set_ring", "desc": "Race condition in packet sockets"}
    ],

    "4.9": [
        {"cve": "CVE-2019-11815", "name": "RDS socket UAF", "desc": "Race in RDS socket handling"},
        {"cve": "CVE-2018-19824", "name": "fs/ioctl mishandling", "desc": "Out-of-bounds access in ioctl"},
        {"cve": "CVE-2019-13272", "name": "Sudo privilege escalation", "desc": "Improper ptrace cleanup"}
    ],

    "4.14": [
        {"cve": "CVE-2020-25211", "name": "Netfilter Use-after-free", "desc": "Race during garbage collection"},
        {"cve": "CVE-2020-25704", "name": "block layer stack leak", "desc": "Leaking kernel stack into userland"}
    ],

    "4.19": [
        {"cve": "CVE-2021-3732", "name": "Memory leak in net", "desc": "Unfreed memory in socket init"},
        {"cve": "CVE-2021-39698", "name": "Binder driver race", "desc": "Data leak via race condition"}
    ],

    "5.4": [
        {"cve": "CVE-2022-2586", "name": "UAF in nf_tables", "desc": "Use-after-free in rule expressions"},
        {"cve": "CVE-2022-2588", "name": "Heap overflow in netfilter", "desc": "Improperly validated data len"},
        {"cve": "CVE-2022-2639", "name": "Double free in nft_payload", "desc": "Crash from repeated insertions"}
    ],

    "5.10": [
        {"cve": "CVE-2023-0179", "name": "Stack buffer overflow in netfilter", "desc": "Improper input size in nft_parse_expr"},
        {"cve": "CVE-2022-3545", "name": "Reference count leak", "desc": "net/sched cls_u32 memory issue"}
    ]
})
kernel_exploits.update({

    "5.10": [
        {"cve": "CVE-2023-0266", "name": "snd_pcm use-after-free", "desc": "Race condition in ALSA PCM subsystem"},
        {"cve": "CVE-2023-0386", "name": "OverlayFS Escalation", "desc": "Improper handling of user namespaces"},
        {"cve": "CVE-2023-0179", "name": "Netfilter OOB", "desc": "Stack overflow in netfilter expression parsing"},
        {"cve": "CVE-2023-1078", "name": "io_uring exploit", "desc": "Improper access in io_uring opcode"}
    ],

    "5.15": [
        {"cve": "CVE-2023-0597", "name": "io_uring UAF", "desc": "Use-after-free in io_uring request completion"},
        {"cve": "CVE-2023-1859", "name": "nf_tables UAF", "desc": "Dangling pointer in rule expressions"},
        {"cve": "CVE-2023-28464", "name": "netlink race", "desc": "Race in netlink message handling"},
        {"cve": "CVE-2023-1829", "name": "tcindex heap overflow", "desc": "Heap overwrite in packet scheduler"}
    ],

    "6.1": [
        {"cve": "CVE-2023-3610", "name": "kcm UAF", "desc": "Use-after-free in kernel connection multiplexor"},
        {"cve": "CVE-2023-39194", "name": "netfilter double-free", "desc": "Memory corruption via NFT_RULE"},
        {"cve": "CVE-2023-42754", "name": "tipc info leak", "desc": "Uninitialized struct in TIPC protocol"},
        {"cve": "CVE-2023-39194", "name": "nft_dynset race", "desc": "Race condition in netfilter"}
    ],

    "6.4": [
        {"cve": "CVE-2023-45871", "name": "tls offload UAF", "desc": "UAF in TLS socket offload support"},
        {"cve": "CVE-2023-47233", "name": "virtio_net double-free", "desc": "Race on cleanup of virtqueues"}
    ],

    "Samsung": [
        {"cve": "CVE-2020-25220", "name": "SEAndroid bypass", "desc": "Samsung-specific SEPolicy bypass"},
        {"cve": "CVE-2021-25337", "name": "Samsung TrustZone bug", "desc": "Access to secure world functions"},
        {"cve": "CVE-2022-22292", "name": "Samsung NPU buffer overflow", "desc": "Out-of-bounds in neural processing"},
        {"cve": "CVE-2022-26474", "name": "Samsung RKP memory leak", "desc": "Leakage of protected memory info"}
    ],

    "MTK": [
        {"cve": "CVE-2021-0661", "name": "MTK WiFi kernel vuln", "desc": "OOB write in MediaTek WiFi driver"},
        {"cve": "CVE-2021-0662", "name": "MTK CAM driver crash", "desc": "Null dereference in camera kernel"},
        {"cve": "CVE-2022-20009", "name": "MTK MD1 DMA buffer overwrite", "desc": "Race in modem core driver"},
        {"cve": "CVE-2022-20137", "name": "MTK GPU info leak", "desc": "Exposure of GPU memory mappings"}
    ],

    "HiSilicon": [
        {"cve": "CVE-2021-4001", "name": "Hisilicon watchdog overflow", "desc": "Stack overflow in watchdog driver"},
        {"cve": "CVE-2022-23457", "name": "Kirins SMMU bypass", "desc": "Privilege escalation in IOMMU config"}
    ]
})
kernel_exploits.update({

    "6.5": [
        {"cve": "CVE-2023-5197", "name": "tcp_ack Overflow", "desc": "Out-of-bounds memory write in TCP"},
        {"cve": "CVE-2023-5345", "name": "unix_stream UAF", "desc": "Use-after-free on socket shutdown"},
        {"cve": "CVE-2023-45662", "name": "TLS kernel crash", "desc": "Improper TLS handshake in kernel"},
        {"cve": "CVE-2023-5717", "name": "xfrm_dump crash", "desc": "NULL dereference in IPsec xfrm subsystem"}
    ],

    "6.6": [
        {"cve": "CVE-2023-6200", "name": "Infiniband queue overflow", "desc": "Buffer overwrite via IB stack"},
        {"cve": "CVE-2023-6121", "name": "OverlayFS race", "desc": "Race in overlay layer creation"},
        {"cve": "CVE-2023-6817", "name": "netfilter crash on rule deletion", "desc": "Memory corruption on table flush"}
    ],

    "6.8": [
        {"cve": "CVE-2024-1086", "name": "netfilter race condition", "desc": "Race in netfilter expression setup"},
        {"cve": "CVE-2024-23851", "name": "UAF in ipvlan driver", "desc": "Use-after-free on socket teardown"},
        {"cve": "CVE-2024-24576", "name": "TCP stack panic", "desc": "Crash in TCP retransmit logic"},
        {"cve": "CVE-2024-28597", "name": "OverlayFS namespace flaw", "desc": "Bypass of mount restrictions"}
    ],

    "6.9": [
        {"cve": "CVE-2024-32290", "name": "Heap info leak via io_uring", "desc": "Sensitive memory exposure"},
        {"cve": "CVE-2024-32896", "name": "OverlayFS + setuid bypass", "desc": "Privilege escalation via merged fs"},
        {"cve": "CVE-2024-31223", "name": "AF_UNIX DoS", "desc": "Crash on closed sockets"},
        {"cve": "CVE-2024-34707", "name": "netfilter double-free", "desc": "Race on concurrent rule update"}
    ],

    "Huawei": [
        {"cve": "CVE-2023-32960", "name": "Hisilicon Timer overflow", "desc": "Integer overflow in timer init"},
        {"cve": "CVE-2023-45299", "name": "TrustZone escape", "desc": "Bypass secure-world syscall check"},
        {"cve": "CVE-2024-15123", "name": "Huawei eBPF kernel info leak", "desc": "eBPF verifier issue in custom kernel"}
    ],

    "Oppo": [
        {"cve": "CVE-2022-20345", "name": "OPLUS diag char device", "desc": "Exposed debug interface in ColorOS"},
        {"cve": "CVE-2023-23347", "name": "Realme kernel memory leak", "desc": "Improper memory handling in audio driver"},
        {"cve": "CVE-2023-39990", "name": "ColorOS binder crash", "desc": "Crash when using debug services"},
        {"cve": "CVE-2024-13742", "name": "OPPO input driver vuln", "desc": "Input method bypass in kernel context"}
    ]
})
kernel_exploits.update({

    "5.15": [
        {"cve": "CVE-2023-1989", "name": "btrfs logical corruption", "desc": "Race in btrfs' logical zone writes"},
        {"cve": "CVE-2023-3117", "name": "overlayfs crash", "desc": "Dangling inode pointer dereference"},
        {"cve": "CVE-2023-1829", "name": "tcindex heap overflow", "desc": "Heap overwrite in packet classifier"},
        {"cve": "CVE-2023-3776", "name": "cls_fw UAF", "desc": "Use-after-free in firewall classifier"}
    ],

    "6.0": [
        {"cve": "CVE-2022-3621", "name": "tls_ctx race", "desc": "Race condition in TLS socket cleanup"},
        {"cve": "CVE-2022-3543", "name": "watch_queue info leak", "desc": "Leak of kernel memory via watch_queue"},
        {"cve": "CVE-2022-3623", "name": "net_filter UAF", "desc": "Use-after-free during filter match"}
    ],

    "6.3": [
        {"cve": "CVE-2023-23455", "name": "AF_PACKET heap overflow", "desc": "Heap overwrite via malformed packet"},
        {"cve": "CVE-2023-24865", "name": "io_uring misconfig", "desc": "Mishandling of opcode restrictions"},
        {"cve": "CVE-2023-27510", "name": "BPF filter escape", "desc": "Privilege escalation via eBPF mischeck"}
    ],

    "6.6": [
        {"cve": "CVE-2023-7122", "name": "netfilter OOB", "desc": "Out-of-bounds access in NFT rule chains"},
        {"cve": "CVE-2023-7158", "name": "sock_map crash", "desc": "NULL deref in sk_msg_recvmsg path"},
        {"cve": "CVE-2023-7306", "name": "binder refcount overflow", "desc": "Android binder vulnerability"},
        {"cve": "CVE-2024-1011", "name": "NFC driver UAF", "desc": "Race in NCI socket release"}
    ],

    "Pixel": [
        {"cve": "CVE-2022-20186", "name": "Pixel GPU info leak", "desc": "Kernel info exposed via debugfs"},
        {"cve": "CVE-2022-20231", "name": "Pixel Trusty bypass", "desc": "Escape secure world via improper call"},
        {"cve": "CVE-2023-21278", "name": "Pixel audio driver LPE", "desc": "Stack overflow via PCM control ioctl"}
    ],

    "LineageOS": [
        {"cve": "CVE-2023-29718", "name": "Lineage debug backdoor", "desc": "Leftover test interface in kernel"},
        {"cve": "CVE-2023-32109", "name": "Netd LPE", "desc": "Privilege escalation via ioctl with root perms"}
    ],

    "AOSP": [
        {"cve": "CVE-2022-20119", "name": "GKI kernel heap spray", "desc": "Heap overwrite in vendor driver"},
        {"cve": "CVE-2022-20458", "name": "Binder UAF", "desc": "Use-after-free in kernel binder context"},
        {"cve": "CVE-2022-20346", "name": "ION memory info leak", "desc": "Userland access to memory map"},
        {"cve": "CVE-2022-20467", "name": "procfs abuse", "desc": "Leaking kernel threads via /proc trickery"}
    ],

    "General": [
        {"cve": "CVE-2022-2319", "name": "snd_ctl UAF", "desc": "Race in ALSA control ioctl"},
        {"cve": "CVE-2022-20349", "name": "vendor_debug LPE", "desc": "Misconfigured char device in debug builds"},
        {"cve": "CVE-2022-2480", "name": "media_codec crash", "desc": "NULL dereference in media codec core"},
        {"cve": "CVE-2022-20144", "name": "system_server crash", "desc": "Denial of service via malicious app"}
    ]
})
kernel_exploits.update({

    "6.10": [
        {"cve": "CVE-2024-36901", "name": "netfilter map leak", "desc": "Improper cleanup of NFT maps"},
        {"cve": "CVE-2024-36902", "name": "memory leak via netlink", "desc": "Missing kfree on socket error"},
        {"cve": "CVE-2024-37004", "name": "tcp retrans crash", "desc": "Panic in tcp retransmit queue"},
        {"cve": "CVE-2024-37691", "name": "xfrm SADB heap overflow", "desc": "Out-of-bounds in xfrm migration"}
    ],

    "6.11": [
        {"cve": "CVE-2024-39822", "name": "netfilter NULL deref", "desc": "Null pointer dereference in chain flush"},
        {"cve": "CVE-2024-40018", "name": "AF_PACKET double-free", "desc": "Double kfree in packet destructor"},
        {"cve": "CVE-2024-40237", "name": "overlayfs write bypass", "desc": "Write restriction bypass in merged fs"}
    ],

    "7.0": [
        {"cve": "CVE-2024-41213", "name": "io_uring memory leak", "desc": "Unreleased ring buffer on teardown"},
        {"cve": "CVE-2024-41412", "name": "BPF filter crash", "desc": "Unvalidated pointer in JIT path"},
        {"cve": "CVE-2024-41517", "name": "eBPF verifier logic flaw", "desc": "Bypass of eBPF safety checks"}
    ],

    "Fuchsia": [
        {"cve": "CVE-2023-42113", "name": "zx_channel_create crash", "desc": "Improper permission setup in Zircon"},
        {"cve": "CVE-2023-42114", "name": "sysmem_heap leak", "desc": "Memory leak in sysmem allocator"},
        {"cve": "CVE-2023-42115", "name": "vm_object UAF", "desc": "Use-after-free in VMO clone"}
    ],

    "Snapdragon": [
        {"cve": "CVE-2022-25699", "name": "DSP service leak", "desc": "Improper access in kernel DSP interface"},
        {"cve": "CVE-2022-25707", "name": "TZBSP mem corruption", "desc": "Memory overwrite in trusted execution"},
        {"cve": "CVE-2023-33027", "name": "GPU buffer overflow", "desc": "Out-of-bounds in KGSL ioctl"}
    ],

    "Unisoc": [
        {"cve": "CVE-2022-38694", "name": "pm_service DoS", "desc": "Crash in Unisoc power mgmt"},
        {"cve": "CVE-2022-38695", "name": "modem kernel write", "desc": "Access to sensitive area from userspace"},
        {"cve": "CVE-2023-27678", "name": "audio firmware leak", "desc": "Kernel log spam with memory content"}
    ],

    "Other": [
        {"cve": "CVE-2023-21475", "name": "KVM info leak", "desc": "Hypervisor info leak to guest"},
        {"cve": "CVE-2023-21476", "name": "ashmem double-free", "desc": "Double release of Android shared mem"},
        {"cve": "CVE-2023-21477", "name": "ION heap overflow", "desc": "Improper bounds in ION ioctl"},
        {"cve": "CVE-2023-22104", "name": "Binder fd leak", "desc": "Unclosed file descriptor in Android Binder"},
        {"cve": "CVE-2023-22217", "name": "Binder driver NULL deref", "desc": "Crash during transaction parse"},
        {"cve": "CVE-2023-26544", "name": "media.codec driver overflow", "desc": "OOB write in codec path"},
        {"cve": "CVE-2023-26601", "name": "pm_kernel overwrite", "desc": "Write to read-only area from vendor blob"}
    ]
})
kernel_exploits.update({

    "3.0": [
        {"cve": "CVE-2013-2094", "name": "perf_event overflow", "desc": "Integer overflow in perf_event_open"},
        {"cve": "CVE-2014-3153", "name": "futex privilege escalation", "desc": "Towelroot exploit — futex_requeue abuse"},
        {"cve": "CVE-2015-1805", "name": "ashmem write overflow", "desc": "Write to freed ashmem block"}
    ],

    "3.4": [
        {"cve": "CVE-2016-5195", "name": "Dirty COW", "desc": "Copy-on-write race condition"},
        {"cve": "CVE-2016-6786", "name": "shared memory info leak", "desc": "Kernel address leakage via memory layout"},
        {"cve": "CVE-2016-6787", "name": "use-after-free in binder", "desc": "Binder transaction cleanup bug"}
    ],

    "3.10": [
        {"cve": "CVE-2017-13168", "name": "UAF in ioctl", "desc": "Android-specific ioctl handler flaw"},
        {"cve": "CVE-2017-13218", "name": "ION driver access", "desc": "Read/write out-of-bounds in memory map"},
        {"cve": "CVE-2017-8890", "name": "DCCP double-free", "desc": "Double-free in packet protocol"}
    ],

    "3.18": [
        {"cve": "CVE-2018-9516", "name": "Binder UAF", "desc": "Use-after-free on deferred reply"},
        {"cve": "CVE-2019-2215", "name": "Binder LPE", "desc": "Pixel 2 root — exploit via waitqueue"},
        {"cve": "CVE-2020-0423", "name": "ION UAF", "desc": "Use-after-free in legacy ION ioctl"},
        {"cve": "CVE-2020-11609", "name": "af_unix race", "desc": "Race in garbage collection of sockets"}
    ],

    "4.1": [
        {"cve": "CVE-2016-0728", "name": "keyring reference leak", "desc": "Use-after-free in keyctl (key_gc)"},
        {"cve": "CVE-2015-8966", "name": "UAF in SCSI ioctl", "desc": "Heap corruption via SCSI user cmd"}
    ],

    "4.4": [
        {"cve": "CVE-2017-0627", "name": "binder race", "desc": "Race condition in free_transaction"},
        {"cve": "CVE-2017-7308", "name": "packet socket overflow", "desc": "Heap overwrite via PACKET_RX_RING"},
        {"cve": "CVE-2019-2215", "name": "binder waitqueue exploit", "desc": "Pixel 3, 3a RCE root exploit"}
    ],

    "4.9": [
        {"cve": "CVE-2018-9568", "name": "USB driver crash", "desc": "NULL ptr deref via OTG device"},
        {"cve": "CVE-2019-9456", "name": "v4l2 info leak", "desc": "Uninitialized memory in video capture"},
        {"cve": "CVE-2020-0041", "name": "PMIC UAF", "desc": "Power management heap corruption"}
    ],

    "4.14": [
        {"cve": "CVE-2020-14386", "name": "IP packet queue overflow", "desc": "Integer truncation in skb_data"},
        {"cve": "CVE-2020-1749", "name": "netfilter UAF", "desc": "Double-free in netfilter unregister"},
        {"cve": "CVE-2021-31916", "name": "SECCOMP bypass", "desc": "Improper filtering of syscalls"}
    ],

    "4.19": [
        {"cve": "CVE-2021-35039", "name": "ALSA race", "desc": "Race in PCM control"},
        {"cve": "CVE-2021-28688", "name": "AF_VSOCK info leak", "desc": "Uninitialized memory on accept()"},
        {"cve": "CVE-2022-0185", "name": "FS context escape", "desc": "Container breakout via fscontext_write"}
    ],

    "General": [
        {"cve": "CVE-2022-0847", "name": "Dirty Pipe", "desc": "Write to read-only files via pipe buffer"},
        {"cve": "CVE-2023-0386", "name": "OverlayFS + root", "desc": "Priv esc via xattr overmount"},
        {"cve": "CVE-2020-8835", "name": "eBPF escape", "desc": "Privilege escalation via eBPF maps"},
        {"cve": "CVE-2019-14615", "name": "INTEL GPU memory leak", "desc": "Kernel address leakage via i915"}
    ]
})
kernel_exploits.update({

    "2.6.18": [
        {"cve": "CVE-2006-3626", "name": "PRCTL local root", "desc": "Improper ptrace handling"},
        {"cve": "CVE-2009-1185", "name": "sock_sendpage", "desc": "Local root in socket ops"},
        {"cve": "CVE-2009-2692", "name": "vmsplice root", "desc": "Classic kernel root via splice()"}
    ],

    "2.6.24": [
        {"cve": "CVE-2010-1146", "name": "recvmmsg overflow", "desc": "Integer overflow in recvmmsg syscall"},
        {"cve": "CVE-2010-1188", "name": "ip_fragment corruption", "desc": "Fragment mismerge in IPv4 stack"},
        {"cve": "CVE-2010-2959", "name": "sock_ioctl info leak", "desc": "Uninitialized sock fields"}
    ],

    "2.6.32": [
        {"cve": "CVE-2010-3904", "name": "RDS exploit", "desc": "Remote exploit via RDS socket"},
        {"cve": "CVE-2011-1010", "name": "keyctl UAF", "desc": "Use-after-free on key garbage"},
        {"cve": "CVE-2012-0056", "name": "mem_read LPE", "desc": "Read/write kernel memory via /proc"}
    ],

    "AndroidBinder": [
        {"cve": "CVE-2016-2431", "name": "Binder txn leak", "desc": "Improper refcount on BINDER_WORK_NODE"},
        {"cve": "CVE-2017-0746", "name": "Binder overflow", "desc": "Heap overflow in binder transaction"},
        {"cve": "CVE-2020-0429", "name": "Binder release race", "desc": "Race in binder_free_thread"}
    ],

    "AndroidPM": [
        {"cve": "CVE-2018-9422", "name": "pm_service race", "desc": "Race in power manager driver"},
        {"cve": "CVE-2019-9263", "name": "PM QOS exploit", "desc": "Bypass via ioctl on power device"},
        {"cve": "CVE-2021-0465", "name": "thermal UAF", "desc": "Use-after-free in thermal policy"}
    ],

    "ION & DMA": [
        {"cve": "CVE-2016-6738", "name": "ION refcount overflow", "desc": "Reference leak leads to crash"},
        {"cve": "CVE-2019-2215", "name": "Binder+ION combo", "desc": "Exploit chaining via ION + binder"},
        {"cve": "CVE-2020-0436", "name": "DMA buf miscount", "desc": "Improper unmap in DMA_BUF ioctl"}
    ],

    "PowerSupply & Thermal": [
        {"cve": "CVE-2017-14804", "name": "supply overflow", "desc": "Out-of-bounds in power_supply_read"},
        {"cve": "CVE-2020-0425", "name": "thermal sensor access", "desc": "Improper sysfs permissions"},
        {"cve": "CVE-2022-20011", "name": "battery debugfs leak", "desc": "Leak sensitive data via /sys"}
    ],

    "GPU Drivers": [
        {"cve": "CVE-2017-0610", "name": "Adreno UAF", "desc": "Race in GPU mem allocation"},
        {"cve": "CVE-2020-11167", "name": "Mali GPU root", "desc": "Arbitrary kernel write via GPU buffer"},
        {"cve": "CVE-2022-20122", "name": "IMG GPU crash", "desc": "Crash in PowerVR kernel interface"}
    ],

    "Audio / Media": [
        {"cve": "CVE-2020-0032", "name": "MediaServer crash", "desc": "Audio HAL crash leads to LPE"},
        {"cve": "CVE-2021-0507", "name": "audio_ioctl UAF", "desc": "Race in sound driver ioctl"},
        {"cve": "CVE-2022-20145", "name": "sound_trigger exploit", "desc": "Corrupting kernel stack from HAL"}
    ]
})